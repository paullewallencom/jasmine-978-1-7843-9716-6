var Person = function (age, firstName, lastName) {
	this.age=age;
	this.firstName = firstName;
	this.lastName = lastName;
};