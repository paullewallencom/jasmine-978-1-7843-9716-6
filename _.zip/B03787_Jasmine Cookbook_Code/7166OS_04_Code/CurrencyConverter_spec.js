describe("<ABC> Money Exchange Company: Currency Converter Module, ", function() {
	describe("When Convert Currency Across Region: ", function(){
		xit("Verify that Indian Rupees (INR) " +
				"converted to Us Dollars (USD)", function() {
		});
		xit("Verify that Indian Rupees (INR) " +
				"converted to Japanese Yen (JPY)", function() {
		});	
		xit("Verify that Hong Kong Dollars (HKD) " +
				"converted to US Dollars (USD)", function() {
		});
		xit("Verify that Japanese Yen (JPY) " +
				"converted to US Dollars (USD)", function() {
		});
		xit("Verify that UAE Dirham (AED) " +
				"converted to US Dollars (USD)", function() {
		});
		xit("Verify that British Pound Sterling (GBP) " +
				"converted to US Dollars (USD)", function() {
		});
		xit("Verify that South African Rand (ZAR) converted to " +
				"Indian Rupees (INR)", function() {
		});
		xit("Verify that US Dollars (USD) " +
				"converted to Hong Kong Dollars (HKD)", function() {
		});	
		xit("Verify that US Dollars (USD) " +
				"converted to Japanese Yen (JPY)", function() {
		});	
	});
});
